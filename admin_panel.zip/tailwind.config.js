// tailwind.config.js
module.exports = {
  purge: ["./assets/**/*.{js,jsx,ts,tsx}", "./dashboard.php"],
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {},
  variants: {
    extend: {},
  },
  plugins: [],
};

